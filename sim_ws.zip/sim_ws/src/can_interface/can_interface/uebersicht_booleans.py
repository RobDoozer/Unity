#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
import threading

class BoolTopicMonitor(Node):
    def __init__(self):
        super().__init__('bool_topic_monitor')

        self._subscriptions = []  # Keine Überschreibung von Node-Eigenschaft
        self.values = [None] * 16

        for i in range(1, 17):
            topic_name = f'/bool_topic_{i}'
            sub = self.create_subscription(
                Bool,
                topic_name,
                self.create_callback(i),
                10
            )
            self._subscriptions.append(sub)

        # Timer, um die Anzeige regelmäßig zu aktualisieren (z.B. 1x pro Sekunde)
        self.create_timer(1.0, self.print_values)

        # Gleich zu Beginn einmal ausgeben (in Thread, weil ROS evtl. noch startet)
        threading.Timer(0.5, self.print_values).start()

    def create_callback(self, index):
        def callback(msg):
            idx = index - 1
            if self.values[idx] != msg.data:
                self.values[idx] = msg.data
                self.print_values()
        return callback

    def print_values(self):
        print("\nAktuelle Werte der 16 Bool-Topics:")
        for i, val in enumerate(self.values, start=1):
            status = val if val is not None else "keine Daten"
            print(f'/bool_topic_{i}: {status}')
        print("-" * 40)

def main(args=None):
    rclpy.init(args=args)
    node = BoolTopicMonitor()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

