#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import time

class FahrbefehlPublisher(Node):
    def __init__(self):
        super().__init__('fahrbefehl_publisher')
        self.publisher_ = self.create_publisher(Float32MultiArray, '/freigegebener_fahrbefehl', 10)

        self.timer_period = 5.0  # 5 Sekunden
        self.timer = self.create_timer(self.timer_period, self.timer_callback)

        self.toggle = False
        self.get_logger().info('🚀 FahrbefehlPublisher gestartet (alle 5s)')

    def timer_callback(self):
        msg = Float32MultiArray()
        msg.data = [1.0, 0.0] if self.toggle else [0.0, 0.0]
        self.toggle = not self.toggle

        self.publisher_.publish(msg)
        self.get_logger().info(f'📤 Gesendet: {msg.data}')


def main(args=None):
    rclpy.init(args=args)
    node = FahrbefehlPublisher()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

